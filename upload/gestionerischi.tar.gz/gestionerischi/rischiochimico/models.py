from __future__ import unicode_literals
from django.utils.encoding import python_2_unicode_compatible
from django.conf import settings
from django.db import models

# Create your models here.

class Azienda(models.Model):
	AZ01_user = models.ForeignKey(settings.AUTH_USER_MODEL, verbose_name='Utente')
	#AZ01_codiceazienda = models.IntegerField(primary_key=True, verbose_name='Azienda')
	AZ01_ragionesoc = models.CharField(max_length=60,verbose_name='Ragione Sociale')
	AZ01_indirizzo = models.CharField(max_length=50,verbose_name='Indirizzo')
	AZ01_citta = models.CharField(max_length=50,verbose_name='Citta')
	AZ01_provincia = models.CharField(max_length=2,verbose_name='Provincia')
	AZ01_cap = models.CharField(max_length=5,verbose_name='CAP')
	AZ01_piva = models.CharField(max_length=12,verbose_name='Partita Iva')
	AZ01_codfiscp = models.CharField(max_length=12,verbose_name='Codice Fiscale')
	AZ01_ammin = models.CharField(max_length=40,verbose_name='Amministratore')
	AZ01_medcomp = models.CharField(max_length=40,verbose_name='Medico Competente')
	AZ01_rls = models.CharField(max_length=40,verbose_name='RLS')
	AZ01_rspp = models.CharField(max_length=40,verbose_name='RSPP')
	AZ01_ciclprod = models.CharField(max_length=40,verbose_name='Ciclo Produttivo')
	def __unicode__(self):
		return str(self.AZ01_ragionesoc)
	class Meta:
		verbose_name_plural = 'Aziende'

class MisPrevInc(models.Model):
	#MS01_codice = models.IntegerField(primary_key=True,verbose_name='Codice')
	MS01_descrizione = models.CharField(max_length=50,verbose_name='Descrizione')
	def __unicode__(self):
		return str(self.MS01_descrizione)
	class Meta:
		verbose_name_plural = 'Misure preventive incendi'


class Reparti(models.Model):
	SCARSA = 'SC'
	FAVORITA = 'FV'
	ELEVATA = 'EL'
	PROB_INCENDIO = (
        (SCARSA, 'SCARSA'),
        (FAVORITA, 'FAVORITA'),
        (ELEVATA, 'ELEVATA'),
        )
	BASSA = 'BS'
	LIMITATA = 'LM'
	NOTEVOLE = 'NT'
	PROB_PROPAGAZIONE = (
        (BASSA, 'BASSA'),
        (LIMITATA, 'LIMITATA'),
        (NOTEVOLE, 'NOTEVOLE'),
        )
	RP01_codiceazienda = models.ForeignKey(Azienda, verbose_name='Azienda')
	#RP01_codicerep = models.IntegerField(primary_key=True,verbose_name='Codice Reparto')
	RP01_descrizione = models.CharField(max_length=50,verbose_name='Descrizione')
	RP01_codicemisprevinc = models.ManyToManyField(MisPrevInc,verbose_name='Misure Preventive Incendi')
	RP01_probinc = models.CharField(
		max_length=2, 
		choices = PROB_INCENDIO, 
		default = SCARSA,
	verbose_name='Probabilita incendio')
	RP01_probprobagaz = models.CharField(
		max_length=2, 
		choices = PROB_PROPAGAZIONE, 
		default = BASSA,
	verbose_name='Probabilita di propagazione')
	def __unicode__(self):
		return str(self.RP01_descrizione)
	class Meta:
		verbose_name_plural = 'Reparti'



#class MisPrevReparti(models.Model):
#	MS11_codiceazienda = models.ForeignKey(Azienda, verbose_name='Azienda')
#	MS11_codicerep = models.ForeignKey(Reparti,verbose_name='Reparto')
#	MS11_codicemisprevinc = models.ManyToManyField(MisPrevInc,verbose_name='Misura Preventiva Incendi')
#	def __unicode__(self):
#		return str(self.MS11_codiceazienda)
#	class Meta:
#		verbose_name_plural = 'Misure preventive incendi Reparti'

class MisPrevVibra(models.Model):
	#MS02_codice = models.IntegerField(primary_key=True,verbose_name='Codice')
	MS02_descrizione = models.CharField(max_length=50,verbose_name='Descrizione')
	def __unicode__(self):
		return str(self.MS02_descrizione)
	class Meta:
		verbose_name_plural = 'Misure preventive vibrazioni'


class Mansione(models.Model):
	#MS03_codmansione = models.IntegerField(primary_key=True,verbose_name='Codice')
	MS04_descrizione = models.CharField(max_length=50,verbose_name='Descrizione')
	def __unicode__(self):
		return str(self.MS04_descrizione)
	class Meta:
		verbose_name_plural = 'Mansione'


class Locali(models.Model):
	LC01_codiceazienda = models.ForeignKey(Azienda, verbose_name='Azienda')
	#LC01_codiceloc = models.IntegerField(primary_key=True,verbose_name='Codice Locale')
	LC01_descrizione = models.CharField(max_length=50,verbose_name='Descrizione')
	LC01_dimensioni = models.CharField(max_length=20,verbose_name='Dimensioni')
	def __unicode__(self):
		return str(self.LC01_descrizione)
	class Meta:
		verbose_name_plural = 'Locali'


class Strumenti(models.Model):
	CORINT = 'CI'
	MANBA = 'MB'
	TIPO_VIBRAZIONE = (
        (CORINT, 'CORPO INTERO'),
        (MANBA, 'MANO BRACCIO'),
        )
	LIBCOR = 'LC'
	MISURA = 'MS'
	BNCDAT = 'BD'
	PROV_VIBRAZIONE = (
        (LIBCOR, 'LIBRETTO DEL COSTRUTTORE'),
        (MISURA, 'MISURAZIONE'),
	(BNCDAT, 'BANCA DATI'),
        )
	ST01_codiceazienda = models.ForeignKey(Azienda,verbose_name='Azienda')
	#ST01_codicestrum = models.IntegerField(primary_key=True,verbose_name='Codice Strumento')
	ST01_descrizione = models.CharField(max_length=50,verbose_name='Descrizione')
	ST01_tipovibr = models.CharField(
		max_length=2, 
		choices = TIPO_VIBRAZIONE, 
		default = CORINT,
	verbose_name='Tipologia Vibrazione')
	ST01_produttore = models.CharField(max_length=50,verbose_name='Produttore')
	ST01_modello = models.CharField(max_length=50,verbose_name='Modello')
	ST01_vibrazcostr = models.DecimalField(max_digits=6, decimal_places=4,verbose_name='Vibraz. Costruttore')
	ST01_accvibrazx = models.DecimalField(max_digits=6, decimal_places=4,verbose_name='Accelerazione X')
	ST01_accvibrazy = models.DecimalField(max_digits=6, decimal_places=4,verbose_name='Accelerazione Y')
	ST01_accvibrazz = models.DecimalField(max_digits=6, decimal_places=4,verbose_name='Accelerazione Z')
	ST01_accvibrazw = models.DecimalField(max_digits=6, decimal_places=4,verbose_name='Accelerazione W')
	ST01_origmis = models.CharField(
		max_length=2, 
		choices = PROV_VIBRAZIONE, 
		default = MISURA,
		verbose_name='Origine Misurazione')
	ST01_note = models.CharField(max_length=100,verbose_name='Note')
	ST01_codicemisprevvibra = models.ManyToManyField(MisPrevVibra, verbose_name='Misure preventive vibrazioni')
	ST01_codiceloc = models.ManyToManyField(Locali ,verbose_name='Locale')
	ST01_tempoesp = models.DecimalField(max_digits=6, decimal_places=4,verbose_name='Tempo di esposizione')
	ST01_fattcorr = models.DecimalField(max_digits=6, decimal_places=4,verbose_name='Fattore di correzione')
	def __unicode__(self):
		return str(self.ST01_descrizione)
	class Meta:
		verbose_name_plural = 'Strumenti'



#class MisPrevStrumenti(models.Model):
#	MS12_codiceazienda = models.ForeignKey(Azienda,verbose_name='Azienda')
#	MS12_codicestrum = models.ForeignKey(Strumenti,verbose_name='Strumenti')
#	MS12_codicemisprevvibra = models.ManyToManyField(MisPrevInc, verbose_name='Misura Preventiva Incendi')
#	class Meta:
#		verbose_name_plural = 'Misure preventive vibrazioni Strumenti'



#class LocaliStrumenti(models.Model):
#	LS01_codiceazienda = models.ForeignKey(Azienda, verbose_name='Azienda')
#	LS01_codicestr = models.ForeignKey(Strumenti, verbose_name='Strumento')
#	LS01_codiceloc = models.ManyToManyField(Locali ,verbose_name='Locale')
#	class Meta:
#		verbose_name_plural = 'Strumentazione dei locali'


class Dipendenti(models.Model):
	DP01_codiceazienda = models.ForeignKey(Azienda, verbose_name='Azienda')
	DP01_codicemansione = models.ForeignKey(Mansione, verbose_name='Mansione')
	#DP01_codicedip = models.IntegerField(primary_key=True,verbose_name='Codice Dipendente')
	DP01_descrizione = models.CharField(max_length=50,verbose_name='Descrizione')
	DP01_datanascita = models.DateField(verbose_name='Data di nascita')
	def __unicode__(self):
		return str(self.DP01_descrizione)
	class Meta:
		verbose_name_plural = 'Dipendenti'


class DipendentiStrumenti(models.Model):
	DS01_codiceazienda = models.ForeignKey(Azienda, verbose_name='Azienda')
	DS01_codicestr = models.ForeignKey(Strumenti, verbose_name='Strumento')
	DS01_codicedip = models.ManyToManyField(Dipendenti, verbose_name='Dipendente')
	DS01_tempoutilizzo = models.CharField(max_length=20,verbose_name='Tempo di utilizzo')
	class Meta:
		verbose_name_plural = 'Strumentazione dei dipendenti'


class Sostanze(models.Model):
	NOSCELTA = 'NS'
	METSTIM = 'MS'
	CUTOFF = 'CO'
	ALGORITMO_CHOICES = (
        (NOSCELTA, '-------'),
        (METSTIM, 'Metodo Stimato'),
        (CUTOFF, 'CUT OFF'),
        )
	SS01_codiceazienda = models.ForeignKey(Azienda, verbose_name='Azienda')
	SS01_codicesost = models.CharField(max_length=20,verbose_name='Codice Sostanza')
	SS01_descrizione = models.CharField(max_length=50,verbose_name='Descrizione')
	SS01_tiposostanza = models.CharField(max_length=50,verbose_name='Tipo Sostanza')
	SS01_dispersione = models.CharField(max_length=50,verbose_name='Dispersione')
	SS01_codicedip = models.ManyToManyField(Dipendenti, verbose_name='Dipendente')
	SS01_disponibilita = models.CharField(max_length=50,verbose_name='Disponibilita')
	SS01_quantita = models.DecimalField(max_digits=6, decimal_places=4,verbose_name='Quantita')
	SS01_tipoalgoritmo = models.CharField(
		max_length=2, 
		choices = ALGORITMO_CHOICES, 
		default = NOSCELTA,
	verbose_name='Metodo di calcolo')
	def __unicode__(self):
		return str(self.SS01_codicesost)
	class Meta:
		verbose_name_plural = 'Sostanze'


#class DipendentiSostanze(models.Model):
#	DS02_codiceazienda = models.ForeignKey(Azienda, verbose_name='Azienda')
#	DS02_codicesost = models.ManyToManyField(Sostanze, verbose_name='Sostanza')
#	DS02_codicedip = models.ManyToManyField(Dipendenti, verbose_name='Dipendente')
#	class Meta:
#		verbose_name_plural = 'Sostanze in uso ai dipendenti'



