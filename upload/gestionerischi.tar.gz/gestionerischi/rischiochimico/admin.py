from django.contrib import admin
from rischiochimico.models import *
from django import forms



# Register your models here.
class AziendeOption(admin.ModelAdmin):
	def get_queryset(self, request):
		qs = super(AziendeOption, self).get_queryset(request)
		if request.user.is_superuser:
			return qs
		return qs.filter(AZ01_user_id=request.user)
	list_display = ( 'AZ01_ragionesoc', 'AZ01_indirizzo','AZ01_citta')
	search_fields = ('AZ01_ragionesoc',)
	#limit_chois_to = request.user.is_authenticated



class RepartiOption(admin.ModelAdmin):
	list_display = ('RP01_codiceazienda', 'RP01_descrizione')
	search_fields = ('RP01_descrizione',)
	raw_id_fields = ('RP01_codiceazienda',)
	def azie(self, Reparti):
		return Reparti.RP01_codiceazienda.AZ01_ragionesoc

	azie.short_description = "Azienda"
        azie.allow_tags = True 


class MisPrevIncOption(admin.ModelAdmin):
	list_display = ('MS01_descrizione',)


class StrumentiOption(admin.ModelAdmin):
	list_display = ('ST01_codiceazienda', 'ST01_descrizione')

class MisPrevVibraOption(admin.ModelAdmin):
	list_display = ('MS02_descrizione',)

#class MisPrevStrumentiOption(admin.ModelAdmin):
#	list_display = ('MS12_codiceazienda', 'MS12_codicestrum')

class LocaliOption(admin.ModelAdmin):
	list_display = ('LC01_codiceazienda', 'LC01_descrizione', 'LC01_dimensioni')
	search_fields = ('LC01_descrizione',)
	raw_id_fields = ('LC01_codiceazienda',)
	def azie(self, Locali):
		return Locali.LC01_codiceazienda.AZ01_ragionesoc

	azie.short_description = "Azienda"
        azie.allow_tags = True 

#class LocaliStrumentiOption(admin.ModelAdmin):
#	list_display = ('LS01_codiceazienda', 'LS01_codicestr')

class DipendentiOption(admin.ModelAdmin):
	list_display = ('DP01_codiceazienda', 'DP01_descrizione')
	search_fields = ( 'DP01_descrizione',)
	raw_id_fields = ('DP01_codiceazienda', 'DP01_codicemansione',)
	def azie(self, Dipendenti):
		return Dipendenti.DP01_codiceazienda.AZ01_ragionesoc

	azie.short_description = "Azienda"
        azie.allow_tags = True 

class DipendentiStrumentiOption(admin.ModelAdmin):
	list_display = ('DS01_codiceazienda', 'DS01_codicestr', 'DS01_tempoutilizzo')

class SostanzeOption(admin.ModelAdmin):
	list_display = ('SS01_codiceazienda', 'SS01_codicesost', 'SS01_descrizione', 'SS01_tiposostanza', 'SS01_dispersione', 'SS01_disponibilita', 'SS01_quantita', 'SS01_tipoalgoritmo')
	search_fields = ('SS01_codicesost', 'SS01_descrizione',)
	raw_id_fields = ('SS01_codiceazienda',)
	def azie(self, Sostanze):
		return Sostanze.SS01_codiceazienda.AZ01_ragionesoc

	azie.short_description = "Azienda"
        azie.allow_tags = True 

class MansioneOption(admin.ModelAdmin):
	list_display = ('MS04_descrizione',)
	search_fields = ('MS04_descrizione',)


class StrumentiOption(admin.ModelAdmin):
	list_display = ('ST01_codiceazienda',  'ST01_descrizione', 'ST01_tipovibr')
	search_fields = ('ST01_descrizione',)
	raw_id_fields = ('ST01_codiceazienda',)
	def azie(self, Strumenti):
		return Strumenti.ST01_codiceazienda.AZ01_ragionesoc

	azie.short_description = "Azienda"
        azie.allow_tags = True 


#class DipendentiSostanzeOption(admin.ModelAdmin):
#	list_display = ('DS02_codiceazienda', 'DS02_codicesost' )

admin.site.register(Azienda, AziendeOption)
admin.site.register(Reparti, RepartiOption)
admin.site.register(MisPrevInc, MisPrevIncOption)
#admin.site.register(MisPrevReparti, MisPrevRepartiOption)
admin.site.register(Strumenti, StrumentiOption)
admin.site.register(MisPrevVibra, MisPrevVibraOption)
#admin.site.register(MisPrevStrumenti, MisPrevStrumentiOption)
admin.site.register(Locali, LocaliOption)
#admin.site.register(LocaliStrumenti, LocaliStrumentiOption)
admin.site.register(Dipendenti, DipendentiOption)
admin.site.register(DipendentiStrumenti, DipendentiStrumentiOption)
admin.site.register(Sostanze, SostanzeOption)
#admin.site.register(DipendentiSostanze)
admin.site.register(Mansione, MansioneOption)
#admin.site.register(AziendeOption)
