from django.shortcuts import render
from django.http import HttpResponse
from models import *



from templated_docs import fill_template
from templated_docs.http import FileResponse

from rischiochimico.forms import AziendaForm

# Create your views here.
def aziende(request):
	elenco=""
	for aziende in Azienda.objects.all().order_by('AZ01_codiceazienda'):
		elenco += "'%s' di %s, %s<br>" % (aziende.AZ01_codiceazienda,
						aziende.AZ01_ragionesoc, aziende.AZ01_ragionesoc)
	return HttpResponse(elenco)

def reparti(request):
	elenco=""
	for reparti in Reparti.objects.all().order_by('RP01_codiceazienda'):
		elenco += "'%s' di %s, %s<br>" % (reparti.RP01_codiceazienda,
						reparti.RP01_codicerep, reparti.RP01_descrizione)
	return HttpResponse(elenco)

def lav(request):
	elenco=""
	for lav in Lavorazioni.objects.all().order_by('LV01_codiceazienda'):
		elenco += "'%s' di %s, %s<br>" % (lav.LV01_codiceazienda,
						lav.LV01_codicelav, lav.LV01_descrizione)
	return HttpResponse(elenco)

def str(request):
	elenco=""
	for str in Strumenti.objects.all().order_by('ST01_codiceazienda'):
		elenco += "'%s' di %s, %s<br>" % (str.ST01_codiceazienda,
						str.ST01_codicestrum, str.ST01_descrizione)
	return HttpResponse(elenco)

def loc(request):
	elenco=""
	for loc in Locali.objects.all().order_by('LC01_codiceazienda'):
		elenco += "'%s' di %s, %s<br>" % (loc.LC01_codiceazienda, loc.LC01_codiceloc,
						loc.LC01_descrizione, loc.LC01_dimensioni)
	return HttpResponse(elenco)

def dipe(request):
	elenco=""
	for dipe in Dipendenti.objects.all().order_by('DP01_codiceazienda'):
		elenco += "'%s' di %s, %s<br>" % (dipe.DP01_codiceazienda,
						dipe.DP01_codicedip, dipe.DP01_descrizione)
	return HttpResponse(elenco)

def sost(request):
	elenco=""
	for sost in Sostanze.objects.all().order_by('SS01_codiceazienda'):
		elenco += "'%s' di %s, %s<br>" % (sost.SS01_codiceazienda, sost.SS01_codicesost,
						sost.SS01_descrizione, sost.SS01_tiposostanza,
						sost.SS01_dispersione, sost.SS01_disponibilita,
						sost.SS01_quantita, sost.SS01_tipoalgoritmo)
	return HttpResponse(elenco)



def azienda_view(request):
    form = AziendaForm(request.POST or None)

    if form.is_valid():
	doctype = form.cleaned_data['format']
        filename = fill_template(
            'rischiochimico/invoice.odt', form.cleaned_data,
            output_format=doctype)
        visible_filename = 'invoice.{}'.format(doctype)

        return FileResponse(filename, visible_filename)
    else:
        return render(request, 'rischiochimico/form.html', {'form': form})
