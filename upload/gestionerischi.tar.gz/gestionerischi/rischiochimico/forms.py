from django import forms

from rischiochimico.models import Azienda


class AziendaForm(forms.Form):
    FORMAT_CHOICES = (
        ('pdf', 'PDF'),
        ('docx', 'MS Word'),
        ('html', 'HTML'),
    )
    AZ01_codiceazienda = forms.IntegerField(label='numero #')
    AZ01_ragionesoc = forms.CharField(label='RagioneSociale #')
    format = forms.ChoiceField(choices=FORMAT_CHOICES)
